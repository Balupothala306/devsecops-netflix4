declare module "videojs-youtube" {}
